package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.MairaViewModel
import com.example.ui.screens.AutomationEngineScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ScreenAwarenessScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VoiceMacrosScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MairaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MairaMainApp(viewModel = viewModel)
            }
        }
    }
}

enum class NavigationItem(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    HOME("home", "Assistant", Icons.Default.Psychology),
    SCREEN("screen", "Parser", Icons.Default.Smartphone),
    AUTOMATION("automation", "Engine", Icons.Default.Speed),
    MACROS("macros", "Macros", Icons.Default.RecordVoiceOver),
    HISTORY("history", "History", Icons.Default.History),
    SETTINGS("settings", "Settings", Icons.Default.Settings)
}

@Composable
fun MairaMainApp(viewModel: MairaViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: NavigationItem.HOME.route

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0D111D),
                contentColor = Color.White
            ) {
                NavigationItem.entries.forEach { item ->
                    val isSelected = currentRoute == item.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = if (isSelected) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.5f)
                            )
                        },
                        label = {
                            Text(
                                text = item.title,
                                fontSize = 10.sp,
                                color = if (isSelected) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.5f)
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0xFF1E283A)
                        ),
                        modifier = Modifier.testTag("nav_item_${item.route}")
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavigationItem.HOME.route,
            modifier = Modifier
                .padding(innerPadding)
                .background(Color(0xFF0B0F19))
        ) {
            composable(NavigationItem.HOME.route) {
                HomeScreen(viewModel = viewModel)
            }
            composable(NavigationItem.SCREEN.route) {
                ScreenAwarenessScreen(viewModel = viewModel)
            }
            composable(NavigationItem.AUTOMATION.route) {
                AutomationEngineScreen(viewModel = viewModel)
            }
            composable(NavigationItem.MACROS.route) {
                VoiceMacrosScreen(viewModel = viewModel)
            }
            composable(NavigationItem.HISTORY.route) {
                HistoryScreen(viewModel = viewModel)
            }
            composable(NavigationItem.SETTINGS.route) {
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
