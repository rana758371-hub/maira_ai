package com.example.service

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

class MairaTtsEngine(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isInitialized = false
    private var onSpeechStateChangeListener: ((Boolean) -> Unit)? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.apply {
                language = Locale("en", "IN")
                setSpeechRate(1.0f)
                setPitch(1.05f)
                setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onSpeechStateChangeListener?.invoke(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        onSpeechStateChangeListener?.invoke(false)
                    }

                    override fun onError(utteranceId: String?) {
                        onSpeechStateChangeListener?.invoke(false)
                    }
                })
            }
        } else {
            Log.e("MairaTtsEngine", "TextToSpeech initialization failed")
        }
    }

    fun setSpeechListener(listener: (Boolean) -> Unit) {
        onSpeechStateChangeListener = listener
    }

    fun speak(text: String, language: String = "English") {
        if (!isInitialized || text.isBlank()) return

        val locale = when (language) {
            "Bengali" -> Locale("bn", "IN")
            "Hinglish" -> Locale("hi", "IN")
            else -> Locale("en", "IN")
        }

        try {
            val result = tts?.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MAIRA_UTTERANCE_${System.currentTimeMillis()}")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stop() {
        tts?.stop()
        onSpeechStateChangeListener?.invoke(false)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
