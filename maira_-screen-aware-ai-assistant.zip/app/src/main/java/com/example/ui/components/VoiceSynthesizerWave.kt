package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun VoiceSynthesizerWave(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    waveColor: Color = Color(0xFF00E5FF),
    secondaryColor: Color = Color(0xFF7C4DFF)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val amplitudeMultiplier = if (isActive) 1.0f else 0.25f

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0D111D))
            .padding(horizontal = 12.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val centerY = height / 2f

            // Primary Cyan Wave
            val path1 = Path()
            path1.moveTo(0f, centerY)

            val frequency = 3f
            val baseAmplitude = (height / 3f) * amplitudeMultiplier

            for (x in 0..width.toInt() step 4) {
                val normalizedX = x / width
                val y = centerY + baseAmplitude * sin(normalizedX * frequency * Math.PI.toFloat() + phase)
                path1.lineTo(x.toFloat(), y)
            }

            drawPath(
                path = path1,
                brush = Brush.horizontalGradient(
                    colors = listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFFFF007A))
                ),
                style = Stroke(width = 4.dp.toPx())
            )

            // Secondary Floating Wave
            val path2 = Path()
            path2.moveTo(0f, centerY)
            for (x in 0..width.toInt() step 4) {
                val normalizedX = x / width
                val y = centerY + (baseAmplitude * 0.6f) * sin(normalizedX * (frequency * 1.5f) * Math.PI.toFloat() - phase)
                path2.lineTo(x.toFloat(), y)
            }

            drawPath(
                path = path2,
                color = secondaryColor.copy(alpha = 0.6f),
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}
