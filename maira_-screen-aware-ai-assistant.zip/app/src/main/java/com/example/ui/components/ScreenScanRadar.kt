package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.screen.SimulatedAppScreen
import com.example.data.screen.UiNode

@Composable
fun ScreenScanRadar(
    screen: SimulatedAppScreen,
    highlightNodeId: String?,
    isScanning: Boolean,
    onNodeSelected: (UiNode) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "scan_laser")
    val scanY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(380.dp)
            .testTag("screen_scan_radar_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101622)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                colors = listOf(Color(0xFF00E5FF).copy(alpha = 0.6f), Color(0xFF7C4DFF).copy(alpha = 0.3f))
            )
        )
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Screen Background Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Draw Grid Lines
                val gridColor = Color(0xFF1E283A)
                for (x in 0..width.toInt() step 60) {
                    drawLine(gridColor, Offset(x.toFloat(), 0f), Offset(x.toFloat(), height), strokeWidth = 1f)
                }
                for (y in 0..height.toInt() step 60) {
                    drawLine(gridColor, Offset(0f, y.toFloat()), Offset(width, y.toFloat()), strokeWidth = 1f)
                }

                // Laser Beam Line
                if (isScanning) {
                    val laserYPos = height * scanY
                    drawLine(
                        color = Color(0xFF00E5FF),
                        start = Offset(0f, laserYPos),
                        end = Offset(width, laserYPos),
                        strokeWidth = 4.dp.toPx()
                    )
                }
            }

            // UI Node Elements
            screen.nodes.forEach { node ->
                val isHighlighted = node.id == highlightNodeId
                val nodeColor = when {
                    isHighlighted -> Color(0xFF00FF87)
                    node.isSensitive -> Color(0xFFFF5252)
                    node.isEditable -> Color(0xFFFFD600)
                    else -> Color(0xFF00E5FF)
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(node.widthRatio)
                            .fillMaxHeight(node.heightRatio)
                            .align(
                                Alignment.TopStart
                            )
                            .offset {
                                IntOffset(
                                    x = (node.xRatio * 320).dp.roundToPx(),
                                    y = (node.yRatio * 340).dp.roundToPx()
                                )
                            }
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isHighlighted) Color(0xFF00FF87).copy(alpha = 0.25f)
                                else nodeColor.copy(alpha = 0.12f)
                            )
                            .border(
                                width = if (isHighlighted) 2.5.dp else 1.dp,
                                color = nodeColor,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { onNodeSelected(node) }
                            .padding(4.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = node.text,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1
                                )
                                if (node.isSensitive) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Sensitive",
                                        tint = Color(0xFFFF5252),
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                            }
                            Text(
                                text = "${node.type.name} • ${node.resourceId.substringAfter(":id/")}",
                                fontSize = 8.sp,
                                color = Color.White.copy(alpha = 0.6f),
                                maxLines = 1
                            )
                        }

                        if (isHighlighted) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = "Active Target",
                                tint = Color(0xFF00FF87),
                                modifier = Modifier
                                    .size(20.dp)
                                    .align(Alignment.BottomEnd)
                            )
                        }
                    }
                }
            }

            // Screen Header Overlay
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                color = Color(0xFF0B0F19).copy(alpha = 0.85f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isScanning) Color(0xFF00E5FF) else Color(0xFF00FF87))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ACTIVE SCREEN: ${screen.appName.uppercase()}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E5FF)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = "${screen.nodes.size} UI NODES PARSED",
                        fontSize = 9.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}
