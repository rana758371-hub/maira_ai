package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.automation.AutomationStep
import com.example.data.automation.AutomationWorkflow
import com.example.data.automation.StepActionType
import com.example.data.automation.StepStatus
import com.example.data.db.AutomationLog
import com.example.data.db.MairaDatabase
import com.example.data.db.MairaRepository
import com.example.data.db.SavedMacro
import com.example.data.gemini.GeminiService
import com.example.data.screen.SimulatedAppScreen
import com.example.data.screen.SimulatedScreens
import com.example.data.screen.UiNode
import com.example.service.MairaTtsEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MairaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        MairaDatabase::class.java,
        "maira_db"
    ).build()

    private val repository = MairaRepository(db.mairaDao())
    val ttsEngine = MairaTtsEngine(application)

    private val _activeScreen = MutableStateFlow<SimulatedAppScreen>(SimulatedScreens.whatsappScreen)
    val activeScreen: StateFlow<SimulatedAppScreen> = _activeScreen.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("English")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _currentWorkflow = MutableStateFlow<AutomationWorkflow?>(null)
    val currentWorkflow: StateFlow<AutomationWorkflow?> = _currentWorkflow.asStateFlow()

    private val _highlightNodeId = MutableStateFlow<String?>(null)
    val highlightNodeId: StateFlow<String?> = _highlightNodeId.asStateFlow()

    private val _mairaSpeechText = MutableStateFlow("Hello! I am Maira, your AI Assistant. What can I do on your screen today?")
    val mairaSpeechText: StateFlow<String> = _mairaSpeechText.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _pendingConfirmationStep = MutableStateFlow<AutomationStep?>(null)
    val pendingConfirmationStep: StateFlow<AutomationStep?> = _pendingConfirmationStep.asStateFlow()

    private val _isScanningScreen = MutableStateFlow(false)
    val isScanningScreen: StateFlow<Boolean> = _isScanningScreen.asStateFlow()

    val historyLogs: StateFlow<List<AutomationLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedMacros: StateFlow<List<SavedMacro>> = repository.allMacros
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var executionJob: Job? = null

    init {
        ttsEngine.setSpeechListener { speaking ->
            _isSpeaking.value = speaking
        }
        // Speak initial greeting
        speakText(_mairaSpeechText.value)

        // Seed initial macros if empty
        viewModelScope.launch {
            repository.allMacros.collect { list ->
                if (list.isEmpty()) {
                    repository.addMacro(
                        SavedMacro(
                            title = "Send WhatsApp Message",
                            voicePhrase = "Rahul ko WhatsApp pe message bhejo",
                            language = "Hinglish",
                            targetApp = "WhatsApp",
                            stepsSummary = "Open WhatsApp -> Type Message -> Send"
                        )
                    )
                    repository.addMacro(
                        SavedMacro(
                            title = "Pay GPay ₹500",
                            voicePhrase = "Google Pay pe 500 taka pathao",
                            language = "Bengali",
                            targetApp = "Google Pay",
                            stepsSummary = "Open GPay -> Enter ₹500 -> Confirm & Pay",
                            isSensitive = true
                        )
                    )
                }
            }
        }
    }

    fun setLanguage(lang: String) {
        _selectedLanguage.value = lang
        val greeting = when (lang) {
            "Bengali" -> "নমস্কার! আমি মাইরা, আপনার এআই অ্যাসিস্ট্যান্ট। আজ আপনার ফোনে কী সাহায্য করতে পারি?"
            "Hinglish" -> "Namaste! Main Maira hu, aapki AI assistant. Aaj aapke phone pe kya madad karu?"
            else -> "Hello! I am Maira, your AI Assistant. How can I automate your phone screen today?"
        }
        _mairaSpeechText.value = greeting
        speakText(greeting)
    }

    fun switchActiveScreen(appId: String) {
        val screen = SimulatedScreens.getScreenByAppId(appId)
        _activeScreen.value = screen
        _highlightNodeId.value = null
    }

    fun toggleVoiceListening() {
        if (_isListening.value) {
            _isListening.value = false
        } else {
            _isListening.value = true
            ttsEngine.stop()
            viewModelScope.launch {
                delay(3000)
                _isListening.value = false
                // Execute sample voice command depending on language
                val sampleCommand = when (_selectedLanguage.value) {
                    "Bengali" -> "রাহুলকে হোয়াটসঅ্যাপে মেসেজ পাঠাও: I will call you later"
                    "Hinglish" -> "GPay pe ₹500 bhejo Priya ko"
                    else -> "Turn on Wi-Fi and set brightness to max"
                }
                processUserCommand(sampleCommand)
            }
        }
    }

    fun processUserCommand(prompt: String) {
        if (prompt.isBlank()) return

        executionJob?.cancel()
        _isScanningScreen.value = true
        _mairaSpeechText.value = "Scanning screen nodes & planning automation..."

        viewModelScope.launch {
            delay(1200) // Radar scan simulation
            _isScanningScreen.value = false

            val result = GeminiService.generateMairaResponse(
                userPrompt = prompt,
                activeScreen = _activeScreen.value,
                preferredLanguage = _selectedLanguage.value
            )

            _selectedLanguage.value = result.detectedLanguage
            _mairaSpeechText.value = result.spokenText
            speakText(result.spokenText)

            val workflow = AutomationWorkflow(
                id = "wf_${System.currentTimeMillis()}",
                userPrompt = prompt,
                detectedLanguage = result.detectedLanguage,
                targetAppId = result.steps.firstOrNull()?.targetAppId ?: "whatsapp",
                steps = result.steps,
                isRunning = true
            )

            _currentWorkflow.value = workflow
            switchActiveScreen(workflow.targetAppId)

            startWorkflowExecution(workflow)
        }
    }

    private fun startWorkflowExecution(workflow: AutomationWorkflow) {
        executionJob = viewModelScope.launch {
            val startTime = System.currentTimeMillis()

            for (i in workflow.steps.indices) {
                workflow.currentStepIndex = i
                val step = workflow.steps[i]
                step.status = StepStatus.IN_PROGRESS
                _highlightNodeId.value = step.targetNodeId

                // Check for sensitive action
                if (step.isSensitive || step.actionType == StepActionType.REQUIRE_CONFIRMATION) {
                    step.status = StepStatus.AWAITING_USER_CONFIRMATION
                    workflow.isPausedForConfirmation = true
                    _pendingConfirmationStep.value = step
                    return@launch // Pause execution until user approves/rejects
                }

                // Simulate step execution delay & visual updates
                delay(1500)
                executeStepAction(step)
                step.status = StepStatus.COMPLETED
                _currentWorkflow.value = workflow.copy()
            }

            // Workflow Completed
            workflow.isRunning = false
            workflow.isCompleted = true
            _currentWorkflow.value = workflow.copy()

            val executionTimeMs = System.currentTimeMillis() - startTime
            repository.logAutomation(
                prompt = workflow.userPrompt,
                language = workflow.detectedLanguage,
                targetApp = workflow.targetAppId,
                status = "COMPLETED",
                stepsCompleted = workflow.steps.size,
                totalSteps = workflow.steps.size,
                executionTimeMs = executionTimeMs
            )
        }
    }

    private fun executeStepAction(step: AutomationStep) {
        when (step.actionType) {
            StepActionType.LAUNCH_APP -> switchActiveScreen(step.targetAppId)
            StepActionType.INPUT_TEXT -> {
                val screen = _activeScreen.value
                val updatedNodes = screen.nodes.map { node ->
                    if (node.id == step.targetNodeId && step.inputTextValue != null) {
                        node.copy(currentValue = step.inputTextValue)
                    } else node
                }
                _activeScreen.value = screen.copy(nodes = updatedNodes)
            }
            StepActionType.TOGGLE_SYSTEM_SETTING -> {
                val screen = _activeScreen.value
                val updatedNodes = screen.nodes.map { node ->
                    if (node.id == step.targetNodeId) {
                        val newValue = if (node.currentValue == "ON") "OFF" else "ON"
                        node.copy(currentValue = newValue)
                    } else node
                }
                _activeScreen.value = screen.copy(nodes = updatedNodes)
            }
            StepActionType.SPEAK_RESPONSE -> {
                if (!step.spokenText.isNullOrBlank()) {
                    _mairaSpeechText.value = step.spokenText
                    speakText(step.spokenText)
                }
            }
            else -> {}
        }
    }

    fun approvePendingStep() {
        val step = _pendingConfirmationStep.value ?: return
        val workflow = _currentWorkflow.value ?: return

        _pendingConfirmationStep.value = null
        workflow.isPausedForConfirmation = false
        step.status = StepStatus.COMPLETED

        viewModelScope.launch {
            executeStepAction(step)
            _currentWorkflow.value = workflow.copy()

            // Resume remaining steps
            val nextStepIdx = workflow.currentStepIndex + 1
            if (nextStepIdx < workflow.steps.size) {
                val remainingWorkflow = workflow.copy(currentStepIndex = nextStepIdx)
                _currentWorkflow.value = remainingWorkflow
                startWorkflowExecution(remainingWorkflow)
            } else {
                workflow.isRunning = false
                workflow.isCompleted = true
                _currentWorkflow.value = workflow.copy()

                repository.logAutomation(
                    prompt = workflow.userPrompt,
                    language = workflow.detectedLanguage,
                    targetApp = workflow.targetAppId,
                    status = "COMPLETED",
                    stepsCompleted = workflow.steps.size,
                    totalSteps = workflow.steps.size,
                    executionTimeMs = 3500
                )
            }
        }
    }

    fun rejectPendingStep() {
        val step = _pendingConfirmationStep.value ?: return
        val workflow = _currentWorkflow.value ?: return

        _pendingConfirmationStep.value = null
        step.status = StepStatus.FAILED
        workflow.isRunning = false
        workflow.isPausedForConfirmation = false
        _currentWorkflow.value = workflow.copy()

        val cancelMessage = when (_selectedLanguage.value) {
            "Bengali" -> "ব্যবহারকারী বাতিল করেছেন। কাজটি সম্পূর্ণ হয়নি।"
            "Hinglish" -> "User ne cancel kar diya. Step execute nahi hua."
            else -> "User rejected sensitive step. Automation cancelled for safety."
        }
        _mairaSpeechText.value = cancelMessage
        speakText(cancelMessage)

        viewModelScope.launch {
            repository.logAutomation(
                prompt = workflow.userPrompt,
                language = workflow.detectedLanguage,
                targetApp = workflow.targetAppId,
                status = "CONFIRMATION_REJECTED",
                stepsCompleted = workflow.currentStepIndex,
                totalSteps = workflow.steps.size,
                executionTimeMs = 2000
            )
        }
    }

    fun createMacro(title: String, phrase: String, targetApp: String) {
        viewModelScope.launch {
            repository.addMacro(
                SavedMacro(
                    title = title,
                    voicePhrase = phrase,
                    language = _selectedLanguage.value,
                    targetApp = targetApp,
                    stepsSummary = "Auto-generated workflow macro"
                )
            )
        }
    }

    fun deleteMacro(id: Long) {
        viewModelScope.launch {
            repository.deleteMacro(id)
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    private fun speakText(text: String) {
        ttsEngine.speak(text, _selectedLanguage.value)
    }

    override fun onCleared() {
        super.onCleared()
        ttsEngine.shutdown()
    }
}
