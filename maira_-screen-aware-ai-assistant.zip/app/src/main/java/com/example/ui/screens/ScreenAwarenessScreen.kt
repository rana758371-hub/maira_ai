package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.screen.SimulatedScreens
import com.example.data.screen.UiNode
import com.example.ui.MairaViewModel
import com.example.ui.components.ScreenScanRadar

@Composable
fun ScreenAwarenessScreen(
    viewModel: MairaViewModel,
    modifier: Modifier = Modifier
) {
    val activeScreen by viewModel.activeScreen.collectAsState()
    val isScanning by viewModel.isScanningScreen.collectAsState()
    val highlightNodeId by viewModel.highlightNodeId.collectAsState()

    var selectedInspectorNode by remember { mutableStateOf<UiNode?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // App Selector Bar
        Text(
            text = "SELECT SMARTPHONE APP TO PARSE",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00E5FF),
            letterSpacing = 1.sp
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(end = 12.dp)
        ) {
            val apps = listOf(
                SimulatedScreens.whatsappScreen,
                SimulatedScreens.gpayScreen,
                SimulatedScreens.settingsScreen,
                SimulatedScreens.uberScreen,
                SimulatedScreens.youtubeScreen
            )

            items(apps) { app ->
                val isSelected = activeScreen.appId == app.appId
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) Color(0xFF7C4DFF) else Color(0xFF161C2C))
                        .border(
                            width = 1.dp,
                            color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF232D42),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable {
                            viewModel.switchActiveScreen(app.appId)
                            selectedInspectorNode = null
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                        .testTag("app_select_${app.appId}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = app.appName,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Radar Screen Inspector View
        ScreenScanRadar(
            screen = activeScreen,
            highlightNodeId = highlightNodeId ?: selectedInspectorNode?.id,
            isScanning = isScanning,
            onNodeSelected = { selectedInspectorNode = it }
        )

        // Selected Node Inspection Metadata
        Text(
            text = "ACCESSIBILITY UI TREE NODE DETAILS",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00E5FF),
            letterSpacing = 1.sp
        )

        val targetNode = selectedInspectorNode ?: activeScreen.nodes.firstOrNull()

        if (targetNode != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("node_details_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF121829)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = "Node",
                                tint = Color(0xFF00FF87),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = targetNode.text,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Surface(
                            color = Color(0xFF00E5FF).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Score: ${(targetNode.confidenceScore * 100).toInt()}%",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00E5FF),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "TYPE: ${targetNode.type.name}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                            Text(text = "RESOURCE ID: ${targetNode.resourceId}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                        }
                        Column {
                            Text(text = "BOUNDS: X ${(targetNode.xRatio * 100).toInt()}%, Y ${(targetNode.yRatio * 100).toInt()}%", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                            Text(text = "SENSITIVE: ${if (targetNode.isSensitive) "YES 🔒" else "NO"}", fontSize = 11.sp, color = if (targetNode.isSensitive) Color(0xFFFF5252) else Color(0xFF00FF87))
                        }
                    }

                    if (targetNode.currentValue.isNotBlank()) {
                        Surface(
                            color = Color(0xFF1E283A),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "CURRENT VALUE: '${targetNode.currentValue}'",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD600),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
