package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.automation.StepStatus
import com.example.data.screen.SimulatedScreens
import com.example.ui.MairaViewModel
import com.example.ui.components.MairaAssistantOverlay
import com.example.ui.components.ScreenScanRadar
import com.example.ui.components.SensitiveConfirmationDialog

@Composable
fun HomeScreen(
    viewModel: MairaViewModel,
    modifier: Modifier = Modifier
) {
    val activeScreen by viewModel.activeScreen.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val mairaSpeechText by viewModel.mairaSpeechText.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val isScanning by viewModel.isScanningScreen.collectAsState()
    val highlightNodeId by viewModel.highlightNodeId.collectAsState()
    val currentWorkflow by viewModel.currentWorkflow.collectAsState()
    val pendingConfirmationStep by viewModel.pendingConfirmationStep.collectAsState()

    val scrollState = rememberScrollState()

    // Sensitive Action Dialog Popup
    pendingConfirmationStep?.let { step ->
        SensitiveConfirmationDialog(
            step = step,
            onConfirm = { viewModel.approvePendingStep() },
            onReject = { viewModel.rejectPendingStep() }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner Art
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .testTag("hero_banner_card"),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.img_maira_hero_1785573952979),
                    contentDescription = "Maira Vision Radar Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFF0B0F19).copy(alpha = 0.95f), Color.Transparent)
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(16.dp)
                ) {
                    Surface(
                        color = Color(0xFF00E5FF).copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF))
                    ) {
                        Text(
                            text = "ACCESSIBILITY & SCREEN-CAPTURE ACTIVE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Maira AI Assistant",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Screen Awareness • Device Automation • Voice Control",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.75f)
                    )
                }
            }
        }

        // Maira Floating Overlay Command Center
        val currentStep = currentWorkflow?.steps?.getOrNull(currentWorkflow?.currentStepIndex ?: 0)
        val stepProgress = if (currentWorkflow != null && currentWorkflow!!.steps.isNotEmpty()) {
            (currentWorkflow!!.currentStepIndex + 1).toFloat() / currentWorkflow!!.steps.size
        } else 0f

        MairaAssistantOverlay(
            selectedLanguage = selectedLanguage,
            onLanguageSelected = { viewModel.setLanguage(it) },
            mairaSpeechText = mairaSpeechText,
            isSpeaking = isSpeaking,
            isListening = isListening,
            currentStepText = currentStep?.let { "Step ${it.stepIndex}/${currentWorkflow?.steps?.size}: ${it.title}" },
            stepProgress = stepProgress,
            onVoiceInputClick = { viewModel.toggleVoiceListening() },
            onSendPrompt = { viewModel.processUserCommand(it) }
        )

        // Quick Action Presets
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "AUTOMATION QUICK PRESETS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00E5FF),
                letterSpacing = 1.sp
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(end = 12.dp)
            ) {
                val presets = listOf(
                    PresetAction("preset_wa", "Rahul WhatsApp", "Send 'I will call you later' on WhatsApp", Icons.Default.Chat, Color(0xFF25D366), "whatsapp"),
                    PresetAction("preset_gpay", "GPay ₹500", "Transfer ₹500 to Priya via GPay", Icons.Default.Payments, Color(0xFF1A73E8), "gpay"),
                    PresetAction("preset_set", "System Wi-Fi", "Turn on Wi-Fi and adjust brightness", Icons.Default.Settings, Color(0xFFFF9800), "settings"),
                    PresetAction("preset_uber", "Uber Ride", "Book Uber Auto to Howrah Station", Icons.Default.DirectionsCar, Color(0xFF000000), "uber"),
                    PresetAction("preset_yt", "YouTube Music", "Search Rabindra Sangeet on YouTube", Icons.Default.PlayCircle, Color(0xFFFF0000), "youtube")
                )

                items(presets) { preset ->
                    Card(
                        modifier = Modifier
                            .width(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { viewModel.processUserCommand(preset.command) }
                            .testTag("preset_card_${preset.id}"),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161C2C)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF232D42))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(preset.accentColor.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = preset.icon,
                                        contentDescription = preset.id,
                                        tint = preset.accentColor,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = preset.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Text(
                                text = preset.command,
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.7f),
                                maxLines = 2,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Live Screen Awareness Radar Inspector
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE SCREEN PARSER & BOUNDING BOXES",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00E5FF),
                    letterSpacing = 1.sp
                )
                Text(
                    text = "App: ${activeScreen.appName}",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }

            ScreenScanRadar(
                screen = activeScreen,
                highlightNodeId = highlightNodeId,
                isScanning = isScanning,
                onNodeSelected = { node ->
                    viewModel.processUserCommand("Tap on ${node.text} in ${activeScreen.appName}")
                }
            )
        }

        // Active Workflow Execution Steps
        currentWorkflow?.let { workflow ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("workflow_timeline_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF121829)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7C4DFF).copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = "Engine",
                                tint = Color(0xFF7C4DFF),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AUTOMATION STEPS PIPELINE",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Surface(
                            color = if (workflow.isCompleted) Color(0xFF00FF87).copy(alpha = 0.2f) else Color(0xFFFFD600).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (workflow.isCompleted) "COMPLETED" else "EXECUTING",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (workflow.isCompleted) Color(0xFF00FF87) else Color(0xFFFFD600),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    workflow.steps.forEach { step ->
                        val stepColor = when (step.status) {
                            StepStatus.COMPLETED -> Color(0xFF00FF87)
                            StepStatus.IN_PROGRESS -> Color(0xFF00E5FF)
                            StepStatus.AWAITING_USER_CONFIRMATION -> Color(0xFFFF5252)
                            StepStatus.FAILED -> Color(0xFFFF5252)
                            else -> Color.White.copy(alpha = 0.4f)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1C2438))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(stepColor.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${step.stepIndex}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = stepColor
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = step.title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = step.description,
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                            }
                            if (step.isSensitive) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Sensitive",
                                    tint = Color(0xFFFF5252),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

data class PresetAction(
    val id: String,
    val title: String,
    val command: String,
    val icon: ImageVector,
    val accentColor: Color,
    val appId: String
)
