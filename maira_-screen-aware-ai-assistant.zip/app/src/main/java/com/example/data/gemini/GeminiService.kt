package com.example.data.gemini

import com.example.BuildConfig
import com.example.data.automation.AutomationStep
import com.example.data.automation.StepActionType
import com.example.data.screen.SimulatedAppScreen
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {

    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val MAIRA_SYSTEM_INSTRUCTION = """
You are Maira, an intelligent mobile-first AI Assistant. You have screen-awareness access and device automation capabilities.
You converse fluently in English, Bengali (বাংলা), and Hinglish (Hindi written in Latin script).

Primary Directives:
1. Parse active screen UI nodes, text, and layout context.
2. Automate device actions (click, type, launch, toggle) step-by-step.
3. Keep spoken responses concise, friendly, and natural for voice synthesis.
4. Detect user language preference (Bengali / English / Hinglish) and match it.
"""

    suspend fun generateMairaResponse(
        userPrompt: String,
        activeScreen: SimulatedAppScreen,
        preferredLanguage: String = "Auto"
    ): MairaAiResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isNullOrBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext fallbackLocalEngine(userPrompt, activeScreen, preferredLanguage)
        }

        try {
            val screenContextJson = JSONObject().apply {
                put("appName", activeScreen.appName)
                put("packageName", activeScreen.packageName)
                put("statusText", activeScreen.statusText)
                val nodesArray = JSONArray()
                activeScreen.nodes.forEach { node ->
                    nodesArray.put(JSONObject().apply {
                        put("id", node.id)
                        put("text", node.text)
                        put("type", node.type.name)
                        put("isSensitive", node.isSensitive)
                    })
                }
                put("uiNodes", nodesArray)
            }

            val fullPrompt = """
User Voice/Text Command: "$userPrompt"
Preferred Language: $preferredLanguage
Active Screen Context: $screenContextJson

Instructions:
1. Understand user intent and match their language (Bengali / English / Hinglish).
2. Generate a concise natural spoken response (under 2 sentences).
3. Plan step-by-step device automation steps.
"""

            val requestJson = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", MAIRA_SYSTEM_INSTRUCTION)))
                })
                put("contents", JSONArray().put(JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
                }))
            }

            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (response.isSuccessful && responseString.isNotBlank()) {
                val jsonResp = JSONObject(responseString)
                val candidates = jsonResp.optJSONArray("candidates")
                val text = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")

                if (!text.isNullOrBlank()) {
                    return@withContext parseMairaTextToResult(text, userPrompt, activeScreen)
                }
            }

            fallbackLocalEngine(userPrompt, activeScreen, preferredLanguage)
        } catch (e: Exception) {
            e.printStackTrace()
            fallbackLocalEngine(userPrompt, activeScreen, preferredLanguage)
        }
    }

    private fun parseMairaTextToResult(
        aiOutput: String,
        userPrompt: String,
        screen: SimulatedAppScreen
    ): MairaAiResult {
        val detectedLang = when {
            userPrompt.contains("বাংলা", ignoreCase = true) || userPrompt.any { it in '\u0980'..'\u09FF' } -> "Bengali"
            userPrompt.contains("kar", ignoreCase = true) || userPrompt.contains("bhejo", ignoreCase = true) || userPrompt.contains("bolo", ignoreCase = true) || userPrompt.contains("kaise", ignoreCase = true) -> "Hinglish"
            else -> "English"
        }

        val speechText = aiOutput.lines().firstOrNull { it.isNotBlank() } ?: "Sure! Processing your request on ${screen.appName}."
        val steps = generateStepsForIntent(userPrompt, screen, detectedLang, speechText)

        return MairaAiResult(
            spokenText = speechText,
            detectedLanguage = detectedLang,
            steps = steps,
            isAiPowered = true
        )
    }

    fun fallbackLocalEngine(
        userPrompt: String,
        activeScreen: SimulatedAppScreen,
        language: String
    ): MairaAiResult {
        val lower = userPrompt.lowercase()
        val isBengali = userPrompt.any { it in '\u0980'..'\u09FF' } || lower.contains("bangla") || lower.contains("bengali")
        val isHinglish = lower.contains("karo") || lower.contains("bhejo") || lower.contains("kaise") || lower.contains("dekh") || lower.contains("do")

        val detectedLang = when {
            isBengali -> "Bengali"
            isHinglish -> "Hinglish"
            else -> "English"
        }

        val (spokenText, steps) = when {
            // WhatsApp Message
            lower.contains("whatsapp") || lower.contains("message") || lower.contains("chat") || lower.contains("কথা") -> {
                val textToType = extractMessageText(userPrompt)
                val resp = when (detectedLang) {
                    "Bengali" -> "অবশ্যই! রাহুলকে হোয়াটসঅ্যাপে মেসেজ পাঠানো হচ্ছে: '$textToType'"
                    "Hinglish" -> "Thik hai! Rahul ko WhatsApp message bhej rahi hu: '$textToType'"
                    else -> "Sure! Typing and sending message to Rahul on WhatsApp."
                }
                val s = listOf(
                    AutomationStep(1, "Launch WhatsApp", "Opening WhatsApp chat window", StepActionType.LAUNCH_APP, "whatsapp"),
                    AutomationStep(2, "Select Contact", "Tapping on Rahul Sharma chat thread", StepActionType.SELECT_UI_NODE, "whatsapp", "wa_header"),
                    AutomationStep(3, "Type Message", "Entering text: '$textToType'", StepActionType.INPUT_TEXT, "whatsapp", "wa_input_box", inputTextValue = textToType),
                    AutomationStep(4, "Click Send", "Tapping Send button icon", StepActionType.CLICK_ELEMENT, "whatsapp", "wa_send_btn"),
                    AutomationStep(5, "Confirmation Feedback", "Notifying user of message status", StepActionType.SPEAK_RESPONSE, "whatsapp", spokenText = resp)
                )
                Pair(resp, s)
            }

            // GPay / Money Transfer
            lower.contains("pay") || lower.contains("gpay") || lower.contains("money") || lower.contains("টাকা") || lower.contains("paise") -> {
                val resp = when (detectedLang) {
                    "Bengali" -> "গুগল পে-তে ₹৫০০ টাকা পাঠানোর জন্য আপনার সম্মতি প্রয়োজন।"
                    "Hinglish" -> "Google Pay pe ₹500 bhejne ke liye aapka confirmation chahiye."
                    else -> "Initiating GPay transfer of ₹500. Sensitive action confirmation required."
                }
                val s = listOf(
                    AutomationStep(1, "Launch Google Pay", "Opening GPay payment gateway", StepActionType.LAUNCH_APP, "gpay"),
                    AutomationStep(2, "Select Recipient", "Selecting payee Priya Sen (priya@okaxis)", StepActionType.SELECT_UI_NODE, "gpay", "gpay_avatar"),
                    AutomationStep(3, "Enter Amount", "Setting payment amount ₹500", StepActionType.INPUT_TEXT, "gpay", "gpay_amount_input", inputTextValue = "500"),
                    AutomationStep(4, "Sensitive Action Guard", "Asking user confirmation before UPI payment", StepActionType.REQUIRE_CONFIRMATION, "gpay", "gpay_pay_button", isSensitive = true),
                    AutomationStep(5, "Click Pay", "Executing secure UPI transaction", StepActionType.CLICK_ELEMENT, "gpay", "gpay_pay_button", isSensitive = true),
                    AutomationStep(6, "Payment Receipt", "Confirming transaction success", StepActionType.SPEAK_RESPONSE, "gpay", spokenText = resp)
                )
                Pair(resp, s)
            }

            // System Settings
            lower.contains("wifi") || lower.contains("wi-fi") || lower.contains("setting") || lower.contains("bluetooth") || lower.contains("brightness") -> {
                val resp = when (detectedLang) {
                    "Bengali" -> "ডিভাইসের ওয়াইফাই অন করা হচ্ছে এবং ব্রাইটনেস লেভেল সেট করা হলো।"
                    "Hinglish" -> "Device ki Wi-Fi turn ON kar rahi hu aur brightness adjust kar di hai."
                    else -> "Toggling Wi-Fi switch and updating system device brightness."
                }
                val s = listOf(
                    AutomationStep(1, "Launch Settings", "Opening Android System Settings", StepActionType.LAUNCH_APP, "settings"),
                    AutomationStep(2, "Inspect Controls", "Scanning device network switches", StepActionType.INSPECT_SCREEN_NODES, "settings"),
                    AutomationStep(3, "Toggle Wi-Fi", "Turning Wi-Fi Switch to ON state", StepActionType.TOGGLE_SYSTEM_SETTING, "settings", "set_wifi_switch"),
                    AutomationStep(4, "Adjust Brightness", "Setting brightness level to 85%", StepActionType.TOGGLE_SYSTEM_SETTING, "settings", "set_brightness_slider"),
                    AutomationStep(5, "Status Voice", "Speaking system status update", StepActionType.SPEAK_RESPONSE, "settings", spokenText = resp)
                )
                Pair(resp, s)
            }

            // Uber Ride
            lower.contains("uber") || lower.contains("cab") || lower.contains("ride") || lower.contains("auto") || lower.contains("howrah") -> {
                val resp = when (detectedLang) {
                    "Bengali" -> "হাওড়া স্টেশনের জন্য উবার অটো সিলেক্ট করা হলো। বুক করার জন্য কনফার্ম করুন।"
                    "Hinglish" -> "Howrah Station ke liye Uber Auto select kar diya hai. Booking confirm kijiye."
                    else -> "Selected Uber Auto (₹140) to Howrah Station. Awaiting ride booking approval."
                }
                val s = listOf(
                    AutomationStep(1, "Launch Uber", "Opening Uber Ride app", StepActionType.LAUNCH_APP, "uber"),
                    AutomationStep(2, "Set Destination", "Entering 'Howrah Station' as destination", StepActionType.INPUT_TEXT, "uber", "uber_destination", inputTextValue = "Howrah Station"),
                    AutomationStep(3, "Select Ride Type", "Selecting Uber Auto (₹140)", StepActionType.SELECT_UI_NODE, "uber", "uber_option_auto"),
                    AutomationStep(4, "Sensitive Action Guard", "Confirming payment method and ride booking", StepActionType.REQUIRE_CONFIRMATION, "uber", "uber_book_btn", isSensitive = true),
                    AutomationStep(5, "Confirm Ride", "Tapping 'Confirm Uber Auto' button", StepActionType.CLICK_ELEMENT, "uber", "uber_book_btn", isSensitive = true),
                    AutomationStep(6, "Ride Status", "Speaking cab arrival status", StepActionType.SPEAK_RESPONSE, "uber", spokenText = resp)
                )
                Pair(resp, s)
            }

            // YouTube
            else -> {
                val query = if (userPrompt.isNotBlank()) userPrompt else "Rabindra Sangeet"
                val resp = when (detectedLang) {
                    "Bengali" -> "ইউটিউবে '$query' সার্চ করা হচ্ছে।"
                    "Hinglish" -> "YouTube pe '$query' search kar rahi hu."
                    else -> "Searching for '$query' on YouTube."
                }
                val s = listOf(
                    AutomationStep(1, "Launch YouTube", "Opening YouTube video feed", StepActionType.LAUNCH_APP, "youtube"),
                    AutomationStep(2, "Type Search Query", "Entering query: '$query'", StepActionType.INPUT_TEXT, "youtube", "yt_search_input", inputTextValue = query),
                    AutomationStep(3, "Click Search", "Tapping search icon button", StepActionType.CLICK_ELEMENT, "youtube", "yt_search_btn"),
                    AutomationStep(4, "Play Top Result", "Playing featured video result", StepActionType.CLICK_ELEMENT, "youtube", "yt_play_btn"),
                    AutomationStep(5, "Voice Feedback", "Reporting playback start", StepActionType.SPEAK_RESPONSE, "youtube", spokenText = resp)
                )
                Pair(resp, s)
            }
        }

        return MairaAiResult(
            spokenText = spokenText,
            detectedLanguage = detectedLang,
            steps = steps,
            isAiPowered = false
        )
    }

    private fun generateStepsForIntent(
        userPrompt: String,
        screen: SimulatedAppScreen,
        detectedLang: String,
        speechText: String
    ): List<AutomationStep> {
        val fallback = fallbackLocalEngine(userPrompt, screen, detectedLang)
        return fallback.steps
    }

    private fun extractMessageText(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("call you later") || lower.contains("pore dakbo") -> "I will call you later"
            lower.contains("good morning") || lower.contains("suprabhat") -> "Good morning! Have a great day!"
            lower.contains("reach in 10 mins") || lower.contains("pouchai") -> "Reaching in 10 minutes"
            else -> "Hey, Maira assistant sending this message on your request!"
        }
    }
}

data class MairaAiResult(
    val spokenText: String,
    val detectedLanguage: String,
    val steps: List<AutomationStep>,
    val isAiPowered: Boolean
)
