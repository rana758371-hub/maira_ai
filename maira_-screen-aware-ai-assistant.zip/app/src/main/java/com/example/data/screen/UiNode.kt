package com.example.data.screen

enum class NodeType {
    BUTTON,
    INPUT_FIELD,
    TEXT_LABEL,
    IMAGE_VIEW,
    TOGGLE_SWITCH,
    CARD_CONTAINER,
    HEADER_BAR,
    ICON_BUTTON,
    LIST_ITEM
}

data class UiNode(
    val id: String,
    val text: String,
    val type: NodeType,
    val resourceId: String,
    val xRatio: Float, // 0.0 to 1.0 (relative screen X)
    val yRatio: Float, // 0.0 to 1.0 (relative screen Y)
    val widthRatio: Float,
    val heightRatio: Float,
    val isClickable: Boolean = true,
    val isEditable: Boolean = false,
    val isSensitive: Boolean = false,
    var currentValue: String = "",
    val confidenceScore: Float = 0.98f
)

data class SimulatedAppScreen(
    val appId: String,
    val appName: String,
    val packageName: String,
    val iconName: String,
    val themeColorHex: String,
    val statusText: String,
    val nodes: List<UiNode>
)
