package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "automation_logs")
data class AutomationLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val prompt: String,
    val language: String, // Bengali, English, Hinglish
    val targetApp: String,
    val status: String, // COMPLETED, CONFIRMATION_REJECTED, FAILED
    val stepsCompleted: Int,
    val totalSteps: Int,
    val executionTimeMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_macros")
data class SavedMacro(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val voicePhrase: String,
    val language: String,
    val targetApp: String,
    val stepsSummary: String,
    val isSensitive: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
