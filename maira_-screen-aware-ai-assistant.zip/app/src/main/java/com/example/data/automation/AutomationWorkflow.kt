package com.example.data.automation

import com.example.data.screen.UiNode

enum class StepActionType {
    LAUNCH_APP,
    INSPECT_SCREEN_NODES,
    SELECT_UI_NODE,
    INPUT_TEXT,
    CLICK_ELEMENT,
    TOGGLE_SYSTEM_SETTING,
    REQUIRE_CONFIRMATION,
    SPEAK_RESPONSE
}

enum class StepStatus {
    PENDING,
    IN_PROGRESS,
    AWAITING_USER_CONFIRMATION,
    COMPLETED,
    FAILED,
    SKIPPED
}

data class AutomationStep(
    val stepIndex: Int,
    val title: String,
    val description: String,
    val actionType: StepActionType,
    val targetAppId: String,
    val targetNodeId: String? = null,
    val inputTextValue: String? = null,
    val isSensitive: Boolean = false,
    val spokenText: String? = null,
    var status: StepStatus = StepStatus.PENDING,
    var executedNode: UiNode? = null
)

data class AutomationWorkflow(
    val id: String,
    val userPrompt: String,
    val detectedLanguage: String, // "English", "Bengali", "Hinglish"
    val targetAppId: String,
    val steps: List<AutomationStep>,
    var currentStepIndex: Int = 0,
    var isRunning: Boolean = false,
    var isPausedForConfirmation: Boolean = false,
    var isCompleted: Boolean = false
)
