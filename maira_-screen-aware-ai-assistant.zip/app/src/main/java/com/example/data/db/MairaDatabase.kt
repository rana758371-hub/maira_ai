package com.example.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MairaDao {
    @Query("SELECT * FROM automation_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AutomationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AutomationLog)

    @Query("DELETE FROM automation_logs")
    suspend fun clearLogs()

    @Query("SELECT * FROM saved_macros ORDER BY createdAt DESC")
    fun getAllMacros(): Flow<List<SavedMacro>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMacro(macro: SavedMacro)

    @Query("DELETE FROM saved_macros WHERE id = :id")
    suspend fun deleteMacro(id: Long)
}

@Database(entities = [AutomationLog::class, SavedMacro::class], version = 1, exportSchema = false)
abstract class MairaDatabase : RoomDatabase() {
    abstract fun mairaDao(): MairaDao
}
