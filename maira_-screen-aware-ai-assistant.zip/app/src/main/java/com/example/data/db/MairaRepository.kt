package com.example.data.db

import kotlinx.coroutines.flow.Flow

class MairaRepository(private val dao: MairaDao) {
    val allLogs: Flow<List<AutomationLog>> = dao.getAllLogs()
    val allMacros: Flow<List<SavedMacro>> = dao.getAllMacros()

    suspend fun logAutomation(
        prompt: String,
        language: String,
        targetApp: String,
        status: String,
        stepsCompleted: Int,
        totalSteps: Int,
        executionTimeMs: Long
    ) {
        dao.insertLog(
            AutomationLog(
                prompt = prompt,
                language = language,
                targetApp = targetApp,
                status = status,
                stepsCompleted = stepsCompleted,
                totalSteps = totalSteps,
                executionTimeMs = executionTimeMs
            )
        )
    }

    suspend fun clearHistory() {
        dao.clearLogs()
    }

    suspend fun addMacro(macro: SavedMacro) {
        dao.insertMacro(macro)
    }

    suspend fun deleteMacro(id: Long) {
        dao.deleteMacro(id)
    }
}
