package com.example.data.screen

object SimulatedScreens {

    val whatsappScreen = SimulatedAppScreen(
        appId = "whatsapp",
        appName = "WhatsApp",
        packageName = "com.whatsapp",
        iconName = "chat",
        themeColorHex = "#075E54",
        statusText = "Chatting with Rahul Sharma (Online)",
        nodes = listOf(
            UiNode("wa_header", "Rahul Sharma", NodeType.HEADER_BAR, "com.whatsapp:id/conversation_title", 0.05f, 0.02f, 0.9f, 0.08f, isClickable = true),
            UiNode("wa_chat_history_1", "Rahul: Hey, are you free for a call?", NodeType.TEXT_LABEL, "com.whatsapp:id/message_text_1", 0.08f, 0.15f, 0.7f, 0.08f, isClickable = false),
            UiNode("wa_chat_history_2", "You: In a meeting right now", NodeType.TEXT_LABEL, "com.whatsapp:id/message_text_2", 0.25f, 0.25f, 0.68f, 0.08f, isClickable = false),
            UiNode("wa_input_box", "Type a message...", NodeType.INPUT_FIELD, "com.whatsapp:id/entry", 0.05f, 0.85f, 0.72f, 0.08f, isClickable = true, isEditable = true, currentValue = ""),
            UiNode("wa_attach_btn", "Attach", NodeType.ICON_BUTTON, "com.whatsapp:id/attach", 0.62f, 0.85f, 0.1f, 0.08f),
            UiNode("wa_camera_btn", "Camera", NodeType.ICON_BUTTON, "com.whatsapp:id/camera", 0.73f, 0.85f, 0.08f, 0.08f),
            UiNode("wa_send_btn", "Send Message", NodeType.BUTTON, "com.whatsapp:id/send", 0.82f, 0.85f, 0.15f, 0.08f, isClickable = true, isSensitive = false)
        )
    )

    val gpayScreen = SimulatedAppScreen(
        appId = "gpay",
        appName = "Google Pay (GPay)",
        packageName = "com.google.android.apps.nfc.payment",
        iconName = "payments",
        themeColorHex = "#1A73E8",
        statusText = "Payment Gateway • Fast UPI Transfer",
        nodes = listOf(
            UiNode("gpay_header", "Pay to Priya Sen", NodeType.HEADER_BAR, "com.gpay:id/payee_name", 0.05f, 0.03f, 0.9f, 0.08f),
            UiNode("gpay_avatar", "Priya Sen (priya@okaxis)", NodeType.TEXT_LABEL, "com.gpay:id/upi_id", 0.2f, 0.14f, 0.6f, 0.06f),
            UiNode("gpay_amount_input", "₹ 500", NodeType.INPUT_FIELD, "com.gpay:id/amount_edit_text", 0.15f, 0.24f, 0.7f, 0.12f, isClickable = true, isEditable = true, isSensitive = true, currentValue = "500"),
            UiNode("gpay_note_input", "Add a note (e.g. Dinner share)", NodeType.INPUT_FIELD, "com.gpay:id/note_text", 0.1f, 0.38f, 0.8f, 0.08f, isClickable = true, isEditable = true, currentValue = "Dinner"),
            UiNode("gpay_bank_select", "State Bank of India (**** 4821)", NodeType.CARD_CONTAINER, "com.gpay:id/account_picker", 0.08f, 0.5f, 0.84f, 0.1f, isClickable = true),
            UiNode("gpay_pay_button", "Pay ₹500 Securely", NodeType.BUTTON, "com.gpay:id/pay_btn", 0.1f, 0.78f, 0.8f, 0.1f, isClickable = true, isSensitive = true)
        )
    )

    val settingsScreen = SimulatedAppScreen(
        appId = "settings",
        appName = "System Settings",
        packageName = "com.android.settings",
        iconName = "settings",
        themeColorHex = "#202124",
        statusText = "Android Device Controls & Connectivity",
        nodes = listOf(
            UiNode("set_header", "Settings Search", NodeType.INPUT_FIELD, "com.android.settings:id/search", 0.05f, 0.02f, 0.9f, 0.08f, isClickable = true, isEditable = true),
            UiNode("set_wifi_title", "Wi-Fi Network", NodeType.TEXT_LABEL, "com.android.settings:id/wifi_title", 0.08f, 0.15f, 0.5f, 0.06f),
            UiNode("set_wifi_switch", "Wi-Fi Connected (Home_5G)", NodeType.TOGGLE_SWITCH, "com.android.settings:id/wifi_switch", 0.65f, 0.14f, 0.28f, 0.08f, isClickable = true, currentValue = "ON"),
            UiNode("set_bluetooth_title", "Bluetooth", NodeType.TEXT_LABEL, "com.android.settings:id/bt_title", 0.08f, 0.26f, 0.5f, 0.06f),
            UiNode("set_bluetooth_switch", "Bluetooth", NodeType.TOGGLE_SWITCH, "com.android.settings:id/bt_switch", 0.65f, 0.25f, 0.28f, 0.08f, isClickable = true, currentValue = "OFF"),
            UiNode("set_brightness_label", "Display Brightness Level", NodeType.TEXT_LABEL, "com.android.settings:id/brightness_label", 0.08f, 0.38f, 0.8f, 0.05f),
            UiNode("set_brightness_slider", "75% Brightness", NodeType.CARD_CONTAINER, "com.android.settings:id/brightness_slider", 0.08f, 0.44f, 0.84f, 0.08f, isClickable = true, currentValue = "75%"),
            UiNode("set_flashlight_switch", "Flashlight Torch", NodeType.TOGGLE_SWITCH, "com.android.settings:id/torch_switch", 0.08f, 0.56f, 0.84f, 0.08f, isClickable = true, currentValue = "OFF"),
            UiNode("set_volume_slider", "Media Volume", NodeType.CARD_CONTAINER, "com.android.settings:id/volume_bar", 0.08f, 0.68f, 0.84f, 0.08f, isClickable = true, currentValue = "80%")
        )
    )

    val uberScreen = SimulatedAppScreen(
        appId = "uber",
        appName = "Uber Rides",
        packageName = "com.ubercab",
        iconName = "directions_car",
        themeColorHex = "#000000",
        statusText = "Where to? • Fast Cabs & Autos",
        nodes = listOf(
            UiNode("uber_pickup", "Pickup: Current Location (Salt Lake Sector V)", NodeType.INPUT_FIELD, "com.ubercab:id/pickup_location", 0.08f, 0.05f, 0.84f, 0.08f, isClickable = true, isEditable = true),
            UiNode("uber_destination", "Destination: Howrah Railway Station", NodeType.INPUT_FIELD, "com.ubercab:id/destination_location", 0.08f, 0.15f, 0.84f, 0.08f, isClickable = true, isEditable = true, currentValue = "Howrah Railway Station"),
            UiNode("uber_option_auto", "Uber Auto • ₹140 (4 mins away)", NodeType.CARD_CONTAINER, "com.ubercab:id/option_auto", 0.08f, 0.28f, 0.84f, 0.12f, isClickable = true, currentValue = "SELECTED"),
            UiNode("uber_option_go", "UberGo Sedan • ₹280 (2 mins away)", NodeType.CARD_CONTAINER, "com.ubercab:id/option_go", 0.08f, 0.42f, 0.84f, 0.12f, isClickable = true),
            UiNode("uber_payment_method", "Payment: Amazon Pay (Balance ₹420)", NodeType.CARD_CONTAINER, "com.ubercab:id/payment_selector", 0.08f, 0.62f, 0.84f, 0.08f, isClickable = true),
            UiNode("uber_book_btn", "Confirm Uber Auto (₹140)", NodeType.BUTTON, "com.ubercab:id/confirm_ride_btn", 0.08f, 0.78f, 0.84f, 0.1f, isClickable = true, isSensitive = true)
        )
    )

    val youtubeScreen = SimulatedAppScreen(
        appId = "youtube",
        appName = "YouTube",
        packageName = "com.google.android.youtube",
        iconName = "play_circle",
        themeColorHex = "#FF0000",
        statusText = "Trending Videos & Shorts",
        nodes = listOf(
            UiNode("yt_search_input", "Search Rabindra Sangeet Songs", NodeType.INPUT_FIELD, "com.google.android.youtube:id/search_edit_text", 0.05f, 0.02f, 0.75f, 0.08f, isClickable = true, isEditable = true, currentValue = "Rabindra Sangeet"),
            UiNode("yt_search_btn", "Search", NodeType.ICON_BUTTON, "com.google.android.youtube:id/search_btn", 0.82f, 0.02f, 0.12f, 0.08f, isClickable = true),
            UiNode("yt_video_1", "Top 10 Evergreen Bengali Songs 2026 • 1.2M views", NodeType.CARD_CONTAINER, "com.google.android.youtube:id/video_item_1", 0.05f, 0.15f, 0.9f, 0.3f, isClickable = true),
            UiNode("yt_play_btn", "Play Video", NodeType.BUTTON, "com.google.android.youtube:id/play_btn", 0.1f, 0.48f, 0.35f, 0.08f, isClickable = true),
            UiNode("yt_subscribe_btn", "Subscribe", NodeType.BUTTON, "com.google.android.youtube:id/subscribe_btn", 0.55f, 0.48f, 0.35f, 0.08f, isClickable = true)
        )
    )

    val allScreens = listOf(whatsappScreen, gpayScreen, settingsScreen, uberScreen, youtubeScreen)

    fun getScreenByAppId(id: String): SimulatedAppScreen {
        return allScreens.find { it.appId == id } ?: whatsappScreen
    }
}
